export const code_sample_1 =
`class SomeComponent extends React.Component {
  componentDidMount() {
    console.log('ping');
  }

  render() {
    return <React.Fragment>
      ...Some Component
    </React.Fragment>
  }
}`;

export const empty_ut = 
`describe('PasswordChangeComponent', () => {
  let component: PasswordChangeComponent;
  let fixture: ComponentFixture<PasswordChangeComponent>;

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
      }).compileComponents();

      fixture = TestBed.createComponent(PasswordChangeComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    }),
  );

  afterEach(() => {
    fixture.destroy();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
`;

export const code_sample_requirements = 
`describe('PasswordChangeComponent', () => {

  ...

  // # As a provider, I want to see the password section on My Account so that I can change my password.

  // # Acceptance criteria
  // ## User can enter his old password
  // ## User can enter his new password twice
  // ## Change password button is disabled until the user has entered valid data in the fields
  // ## User is able to change his password if all fields are filled in correctly
  // ## Validations are available on fields
  // ## validation
  // ### Old password:
  // 1. required
  // 1a. Repeat password field should not be empty - added by AntonM
  // 2. Both should match
  
  // Final form validation check
  // Trigger Component's Submit Form function
  `;

  export const mocking_services = 
  `
  describe('PasswordChangeComponent', () => {
    let component: PasswordChangeComponent;
    let fixture: ComponentFixture<PasswordChangeComponent>;
    let accountServiceSpy;
  
    beforeEach(
      async(() => {
        accountServiceSpy = jasmine.createSpyObj(
          'AccountService', [
            'passwordChange',
          ]);
        TestBed.configureTestingModule({
          declarations: [PasswordChangeComponent],
          imports: [TestingModule],
          providers: [
            { provide: AccountService, useValue: accountServiceSpy }
          ],
        }).compileComponents();
  
        fixture = TestBed.createComponent(PasswordChangeComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      }),
    );
  
    afterEach(() => {
      fixture.destroy();
    });
  
    // # As a provider, I want to see the password section on My Account so that I can change my password.
    it('should be created', () => {
      expect(component).toBeTruthy();
    });`;

    export const service_ut = 
    `
    describe('AccountService', () => {
      let httpTestingController: HttpTestingController;
      let accountService: AccountService;
    
      beforeEach(() => {
        TestBed.configureTestingModule({
          imports: [HttpClientTestingModule],
          providers: [
            AccountService,
            { provide: TranslateService, use: { instant: () => {} } },
          ],
        });
        httpTestingController = TestBed.get(HttpTestingController);
        accountService = TestBed.get(AccountService);
      });
    `;
    
    export const service_ut2 = 
    `
    it('getData() should return expected result', () => {
      accountService.getData(fakeProviderId).subscribe(response => {
        expect(response.body).toEqual(fakeAccount, 'should return expected account');
      }, fail);
  
      const req = httpTestingController.expectOne(
        appConfig.endpoints.account.url,
      );
      expect(req.request.method).toEqual('GET');
      req.flush(fakeAccount);
    });
  
    it('getData() should return CommonError', () => {
      const wrongId = 0;
      accountService
        .getData(wrongId)
        .subscribe(
          ...
    `