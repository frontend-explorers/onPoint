import React from 'react';
import theme from './theme';
import {
  BlockQuote,
  Cite,
  CodePane,
  Deck,
  Heading,
  Image,
  Link,
  List,
  ListItem,
  Quote,
  Slide,
  Text,
} from 'spectacle';

import {
  code_sample_1,
  code_sample_requirements,
  empty_ut,
  mocking_services,
  service_ut,
  service_ut2,

} from './snippets';

require('./overrides.css');


export default class Presentation extends React.Component {
  render() {
    return (<React.Fragment>
      <Deck
        transition={['slide']}
        transitionDuration={150}
        theme={theme}
        progress="bar"

      >
        <Slide id="title" bgImage="/images/header.jpg" bgPosition="center top" bgSize="100% auto" bgRepeat="no-repeat" textColor="white">

          <Heading fit style={{ paddingTop: '4rem' }}>Unit testing for Angular</Heading>

          <Text>
            Components, services and state management
          </Text>

          <Text style={{ textAlign: 'right', fontSize: '90%', marginTop: '7rem' }}>
            Anton Mitsev
          </Text>
        </Slide>

        <Slide id="why">
          <Heading size={4} style={{ textAlign: 'right' }}>Why?<br />Do we need all of this?</Heading>
          <List>
            <ListItem style={{ textAlign: 'right' }}>Angular</ListItem>
            <ListItem style={{ textAlign: 'right' }}>Services</ListItem>
            <ListItem style={{ textAlign: 'right' }}>State management</ListItem>
            <ListItem style={{ textAlign: 'right' }}>Unit testing?!</ListItem>
          </List>
        </Slide>

        <Slide id="how-to">
          <Heading size={4} style={{ textAlign: 'right' }}>How to... unit testing</Heading>
          <List>
            <ListItem style={{ textAlign: 'right' }}>Input vs. Output</ListItem>
            <ListItem style={{ textAlign: 'right' }}>A A A
            <List style={{}}>
                <ListItem style={{ textAlign: 'right', fontSize: '0.8em' }}>Arrange</ListItem>
                <ListItem style={{ textAlign: 'right', fontSize: '0.8em' }}>Act</ListItem>
                <ListItem style={{ textAlign: 'right', fontSize: '0.8em' }}>Assert</ListItem>

              </List>
            </ListItem>
          </List>
        </Slide>

        <Slide id="benefits">
          <Heading size={4} style={{ textAlign: 'right' }}>Benefits of unit testing</Heading>
          <List>
            <ListItem style={{ textAlign: 'right' }}>Design requirements in advance</ListItem>
            <ListItem style={{ textAlign: 'right' }}>Regression watch</ListItem>
            <ListItem style={{ textAlign: 'right' }}>Reduce of cost</ListItem>
            <ListItem style={{ textAlign: 'right' }}>...</ListItem>
          </List>
        </Slide>

        <Slide id="empty-ut">
          <Heading size={5}>Creating .spec file</Heading>
          <Text textSize="0.7em">ng generate component ...</Text>
          <CodePane lang="js" theme="external" source={empty_ut} />
        </Slide>

        <Slide id="requirements">
          <Heading size={5}>Requirements in advance</Heading>
          <CodePane lang="js" theme="external" source={code_sample_requirements} />
        </Slide>

        <Slide id="mocking-service">
          <Heading size={5}>Mocking services</Heading>
          <CodePane lang="js" theme="external" source={mocking_services} />
        </Slide>

        <Slide id="service-ut">
          <Heading size={5}>Testing services</Heading>
          <CodePane lang="js" theme="external" source={service_ut} />
        </Slide>

        <Slide id="service-ut2">
          <Heading size={5}>Testing services</Heading>
          <Text textSize="0.7em">(2) ...</Text>
          <CodePane lang="js" theme="external" source={service_ut2} />
        </Slide>

        <Slide id="state-management">
          <Heading size={4}>State management</Heading>

          <Image src="/images/ngrx.png" />
          <Text textSize="0.6em" style={{ textAlign: 'right', paddingTop: '2em' }}>ref: <i>http://targetveb.com/</i></Text>
        </Slide>

        <Slide id="state-management-ut">
          <Heading size={4}>State management unit testing</Heading>
          <List>
            <ListItem style={{ textAlign: 'right' }}>Actions</ListItem>
            <ListItem style={{ textAlign: 'right' }}>Reducers</ListItem>
            <ListItem style={{ textAlign: 'right' }}>Effects</ListItem>
          </List>
        </Slide>

        <Slide id="into-code">
          <Heading size={4}>State management UT code examples...</Heading>
          
        </Slide>

        <Slide id="thanks">
          <Heading caps>Thank you!<br />Q&amp;A</Heading>
        </Slide>
      </Deck>
    </React.Fragment>);
  }
}
