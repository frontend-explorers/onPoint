import BaseModule from './BaseModule';
import RevealingModule from './RevealingModule';

export {BaseModule, RevealingModule};